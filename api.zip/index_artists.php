<!doctype html>
<html lang="en">
<head>
	<title>API Rush2</title>
	<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

</head>
<body>
<div class="section">
	<div class="container">
	<div class="row">
		<table>
			<thead>
				<td>
					<th>Name</th>
					<th>Description</th>
					<th>Biography</th>
					<th>Photo</th>
					<th>Albums</th>
				</td>
			</thead>
			<tbody>
				<td>
					<tr></tr>
				</td>
			</tbody>

		</table>


	</div>
</div>
</div>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.js" integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA=" crossorigin="anonymous"></script>
	<script type="text/javascript" src="materialize/js/materialize.min.js"></script>
	<script type="text/javascript" src="mustache.js"></script>
	<script type="text/javascript" src="api_mustache.js"></script>

</body>
</html>