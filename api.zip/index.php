<!doctype html>
<html lang="en">
<head>
	<title>API Rush2</title>
	<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

</head>
<body>

	<div class="section">
		<div class="row">
			<div class="col s12">
				<div class="row">
					<div class="input-field col s10">
						<i class="material-icons prefix">Search:</i>
						<input type="text" id="autocomplete-input" class="autocomplete">
						<label for="autocomplete-input">Autocomplete</label>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="container">
		<div class="row">
			<div class="section">
				<div class="col s2">
					<a href="index_albums.php" class="waves-effect waves-light btn">Albums</a>	
				</div>
				<div class="col s8">
					<ul class="collapsible" data-collapsible="accordion">
						<li>
							<div class="collapsible-header active"><i class="material-icons"></i>
								<div id="item_albums">

								</div>
								<div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="cols s2">
					<a class="btn-floating btn-large waves-effect waves-light red">Like</a>
				</div>
			</div>		
		</div>

		<div class="row">
			<div class="section">
				<div class="col s2">
					<a href="index_artists.php" class="waves-effect waves-light btn">Artists</a>
				</div>
				<div class="col s8">
					<ul class="collapsible" data-collapsible="accordion">
						<li>
							<div class="collapsible-header active"><i class="material-icons"></i>
								<div id="item_artists">

								</div>
								<div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="col s2">
					<a class="btn-floating btn-large waves-effect waves-light red">Like</a>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="section">
				<div class="col s2">
					<a href="index_tracks.php" class="waves-effect waves-light btn">Tracks</a>
				</div>
				<div class="col s8">
					<ul class="collapsible" data-collapsible="accordion">
						<li>
							<div class="collapsible-header active"><i class="material-icons"></i>
								<div id="item_tracks">

									<div class="collapsible-body">
										<div id="tracks_collapsible">
											<!-- Ici je voudrais afficher le résultat des requetes, quad ce sera collapsible -->
										</div>
									</div>
								</div>
							</div>  
						</li>
					</ul>
				</div>
				<div class="col s2">
					<a class="btn-floating btn-large waves-effect waves-light red">Like</a>
					<div id="play_track">
						
					</div>
				</div>
			</div>
		</div>


	</div>


	<script id="script_albums" type="text/template">
		<h1>Welcoming Albums</h1>

		<ul>
			<li><strong>Album name:</strong> {{name}}</li>
			<li><strong>Description:</strong> {{{description}}}</li>
			<li><strong>Cover:</strong> {{{cover}}}</li>
			<li><strong>Cover small:</strong> {{{cover_small}}}</li>
			<li><strong>Release date:</strong> {{{release_date}}}</li>
			<li><strong>Popularity:</strong> {{{popularity}}}</li>
		</ul>


	</script>

	<script id="script_artists" type="text/template">

		<h1>Welcoming Artists</h1>

		<ul>
			<li><strong>Artists:</strong> {{{name}}}</li>
			<li><strong>Description:</strong> {{{description}}}</li>
			<li><strong>Biography:</strong> {{{bio}}}</li>
			<li><strong>Photos:</strong> {{{photo}}}</li>
		</ul>


	</script>

	<script id="script_tracks" type="text/template">
		<h1>Welcoming tracks</h1>
		
		<ul>
			<li><strong>Song's name:</strong> {{{name}}}</li>
			<li><strong>Number:</strong> {{{description}}}</li>
			<li><strong>Duration:</strong> {{{bio}}}</li>
			<li><strong>MP3:</strong> {{{photo}}}</li>
		</ul>
		
	</script>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.js" integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA=" crossorigin="anonymous"></script>
	<script type="text/javascript" src="materialize/js/materialize.min.js"></script>
	<script type="text/javascript" src="mustache.js"></script>
	<script type="text/javascript" src="api_mustache.js"></script>

</body>
</html>