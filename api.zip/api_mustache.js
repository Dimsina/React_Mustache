
var template_albums = $('#script_albums').html();
var html_albums = Mustache.render(template_albums, {
			id : "",
			artists_id : "",
			artists : "",
			name : "",
			description : "",
			cover : "",
			cover_small : "",
			release_date : "",
			popularity : ""

	});
	$('#item_albums').append(html_albums);

var template_artists = $('#script_artists').html();
var html_artists = Mustache.render(template_artists, {
	
			id :"",
			name : "",
			description : "",
			bio : "",
			photo : ""

	});
	$('#item_artists').append(html_artists);

var template_tracks = $('#script_tracks').html();
var tracks_list = $('#tracks_collapsible').html();
var html_tracks = Mustache.render(template_tracks, {
	
			id :"",
			album_id : "",
			name : "",
			tracks_no : "",
			duration : "",
			mp3 : ""
	});
	$('#item_tracks').append(html_tracks);
	$('#tracks_collapsible').append(html_tracks); /*afficher la liste dans le collapsible*/


	$(document).ready(function(){
 
  	});

	$('input.autocomplete').autocomplete({
    data: {
      "Apple": null,
      "Microsoft": null,
      "Google": 'https://placehold.it/250x250'
    },
    limit: 20, // The max amount of results that can be shown at once. Default: Infinity.
    onAutocomplete: function(val) {
      // Callback function when value is autcompleted.
    },
    minLength: 1, // The minimum length of the input for the autocomplete to start. Default: 1.
  });
